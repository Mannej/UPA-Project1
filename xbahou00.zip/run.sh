source venv/bin/activate
python3 WebScraper.py > url_test.txt
head -n 10 url_test.txt | python3 SoupScraper.py 